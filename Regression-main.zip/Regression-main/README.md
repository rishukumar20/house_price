# Regression
# Imported the Boston House Price dataset from Sklearn library having 13 features and one label
# Loaded the dataset to a pandas data frame and constructed a Heatmap to understand the correlation among the features
# Trained the XGBoost Regressor model using train data with R Squared error of 0.99 and Mean Absolute error of 0.01
# Evaluated the model using test data giving R Squared error of 0.91 and a Mean Absolute error of 1.99
